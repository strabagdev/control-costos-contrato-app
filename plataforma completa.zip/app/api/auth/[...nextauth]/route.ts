import NextAuth from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { pool } from "@/lib/db";

export const authOptions = {
  session: {
    strategy: "jwt",
  },
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        /**
         * IMPORTANTE:
         * - Tu BD usa pgcrypto (crypt)
         * - NO usar bcrypt.compare en Node
         * - La validación correcta es en SQL
         */
        const { rows } = await pool.query(
          `
          SELECT
            usuario_id,
            email,
            nombre,
            rol
          FROM public.usuario
          WHERE email = $1
            AND activo = true
            AND password_hash = crypt($2, password_hash)
          LIMIT 1
          `,
          [credentials.email, credentials.password]
        );

        const user = rows[0];
        if (!user) return null;

        return {
          id: user.usuario_id,
          email: user.email,
          name: user.nombre,
          role: user.rol, // 👈 viene de la BD como 'rol'
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.role = user.role;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.role = token.role;
      }
      return session;
    },
  },
  pages: {
    signIn: "/login",
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
